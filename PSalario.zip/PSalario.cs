﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbxNumFilhos.SelectedIndex = 0;
        }

        private void mskbxNome_Validated(object sender, EventArgs e)
        {
            double nomeFuncionario;

            if (Double.TryParse(mskbxNome.Text, out nomeFuncionario))
                MessageBox.Show("Este nome de funcionário é inválido!");
            else if (mskbxNome.Text == "")
                MessageBox.Show("Nome funcionário não pode estar vazio!");
        }

        private void mskbxSalBruto_Validated(object sender, EventArgs e)
        {
            double salarioBruto;

            if (!Double.TryParse(mskbxSalBruto.Text, out salarioBruto))
                MessageBox.Show("Valor inválido!");
            else if (salarioBruto <= 0)
                MessageBox.Show("Valor deve ser maior que zero");
        }

        private void cbxNumFilhos_Validated(object sender, EventArgs e)
        {
            double numeroFilhos;

            if (!Double.TryParse(cbxNumFilhos.Text, out numeroFilhos))
                MessageBox.Show("Valor inválido!");
        }

        private void btnVerificarDesconto_Click(object sender, EventArgs e)
        {
            double _nomeFuncionario;

            if (Double.TryParse(mskbxNome.Text, out _nomeFuncionario))
            {
                MessageBox.Show("Este nome de funcionário é inválido, digite o nome novamente!");
                mskbxNome.Focus();
            }
            else if (mskbxNome.Text == "")
            {
                MessageBox.Show("Nome do funcionário está vazio, digite o nome!");
                mskbxNome.Focus();
            }

            else
            {
                double salarioBruto;

                if (!Double.TryParse(mskbxSalBruto.Text, out salarioBruto))
                {
                    MessageBox.Show("Valor invalido");
                    mskbxSalBruto.Focus();
                }
                else if (salarioBruto <= 0)
                {
                    MessageBox.Show("Valor tem que ser maior que zero");
                    mskbxSalBruto.Focus();
                }

                else
                {
                    double numFilh;

                    if (!Double.TryParse(cbxNumFilhos.Text, out numFilh))
                    {
                        MessageBox.Show("Valor invalido");
                        cbxNumFilhos.Focus();
                    }

                    else
                    {
                        double descontoINSS;
                        double descontoIRPF;
                        double salarioFamilia;
                        double salarioLiquido;

                        if (salarioBruto <= 800.47)
                        {
                            txtAliqINSS.Text = "7,65%";
                            descontoINSS = salarioBruto * 0.0765;
                        }
                        else if (salarioBruto >= 800.48 && salarioBruto <= 1050)
                        {
                            txtAliqINSS.Text = "8,65%";
                            descontoINSS = salarioBruto * 0.0865;
                        }
                        else if (salarioBruto >= 1050.01 && salarioBruto <= 1400.77)
                        {
                            txtAliqINSS.Text = "9,00%";
                            descontoINSS = salarioBruto * 0.0900;
                        }
                        else if (salarioBruto >= 1400.78 && salarioBruto <= 2801.56)
                        {
                            txtAliqINSS.Text = "11,00%";
                            descontoINSS = salarioBruto * 0.1100;
                        }
                        else 
                        {
                            txtAliqINSS.Text = "Teto";
                            descontoINSS = 308.17;
                        }
                        if (salarioBruto <= 1257.12)
                        {
                            txtAliqIRPF.Text = "Isento";
                            descontoIRPF = salarioBruto * 0;
                        }
                        else if (salarioBruto >= 1257.13 && salarioBruto <= 2512.08)
                        {
                            txtAliqIRPF.Text = "15,00%";
                            descontoIRPF = salarioBruto * 0.1500;
                        }
                        else
                        {
                            txtAliqIRPF.Text = "27,50%";
                            descontoIRPF = salarioBruto * 0.2750;
                        }
                        if (salarioBruto <= 435.52)
                        {
                            salarioFamilia = numFilh * 22.33;
                        }
                        else if (salarioBruto >= 435.53 && salarioBruto <= 654.61)
                        {
                            salarioFamilia = numFilh * 15.74;
                        }
                        else
                        {
                            salarioFamilia = numFilh * 0;
                        }
                        salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;

                        txtDescINSS.Text = descontoINSS.ToString("N2");
                        txtDescIRPF.Text = descontoIRPF.ToString("N2");
                        txtSalFamilia.Text = salarioFamilia.ToString("N2");
                        txtSalLiquido.Text = salarioLiquido.ToString("N2");

                        string sdoDa;
                        string ssrSra;
                        string snomFunc;
                        string ssoltCasad;
                        string snumFilh;

                        if (rbtnF.Checked == true)
                            sdoDa = "da";
                        else
                            sdoDa = "do";

                        if (rbtnF.Checked == true)
                            ssrSra = "Sra.";
                        else
                            ssrSra = "Sr.";

                        if (mskbxNome.Text != "")
                            snomFunc = mskbxNome.Text;
                        else
                            snomFunc = "Erro!";

                        if (rbtnF.Checked == true && cbxCasado.Checked == true)
                            ssoltCasad = "casada";
                        else if (rbtnF.Checked == true && cbxCasado.Checked == false)
                            ssoltCasad = "solteira";
                        else if (rbtnM.Checked == true && cbxCasado.Checked == true)
                            ssoltCasad = "casado";
                        else
                            ssoltCasad = "solteiro";

                        snumFilh = "-1";

                        if (cbxNumFilhos.SelectedItem != "0")
                            snumFilh = "tem " + cbxNumFilhos.SelectedItem + " filho(s)";
                        else if (cbxNumFilhos.SelectedItem == "0")
                            snumFilh = "não tem filho(a)";

                        lblDados.Text = "Os descontos do salário" + " " + sdoDa + " " + ssrSra + " " + snomFunc + " " + "que é" + " " + ssoltCasad + " " + "e que" + " " + snumFilh + " " + "é: ";
                    }
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxNome.Clear();
            mskbxSalBruto.Clear();
            txtAliqINSS.Clear();
            txtAliqIRPF.Clear();
            txtDescINSS.Clear();
            txtDescIRPF.Clear();
            txtSalFamilia.Clear();
            txtSalLiquido.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
